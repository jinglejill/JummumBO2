//usage
<SortableGrid
  blockHeight={205}
  ....
>
    {...}
</SortableGrid>